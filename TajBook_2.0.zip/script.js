// JS код для комментариев, форума, поиска, языков
console.log('TajBook loaded');